package br.com.ehmf.CalculadoraSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
